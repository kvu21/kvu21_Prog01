/**
 * <Car sorting>
 * 
 * CSC 1351 Programming Project No 1
 * Section 002
 * 
 * @author Khoa Vu
 * @since March 17 2024
 */

package orderedlist;

public class Car implements Comparable<Car> {
	// make: make of the car
	// year: year of the car
	// price: price of the car
	private String make;
	private int year;
	private int price;
	
	// Constructor
	// Initializes new car with its make, year, price
	public Car(String make, int year, int price) {
		this.make = make;
		this.year = year;
		this.price = price;
	}
	
	/**
	 * Method to get make of car
	 * @return - make of car
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public String getMake() {
		return make;
	}
	
	/**
	 * Method to get year of car
	 * @return - year of car
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public int getYear() {
		return year;
	}
	
	/**
	 * Method to get price of car
	 * @return - price of car
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public int getPrice() {
		return price;
	}
	
	/**
	 * Method to compare car with another car to sort
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	@Override
	public int compareTo (Car other) {
		if (this.make.compareTo(other.make) < 0) {
            return -1;
            
        } else if (this.make.compareTo(other.make) > 0) {
            return 1;
            
        } else {
            return Integer.compare(this.year, other.year);
        }

	}
	
	/**
	 * Method to format ordered list in string format
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	@Override
	public String toString() {
		return "Make: " + make + ", Year: " + year + ", Price: " + price + ";";
	}
}
