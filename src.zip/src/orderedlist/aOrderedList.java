/**
 * <Array implementation>
 * 
 * CSC 1351 Programming Project No 1
 * Section 002
 * 
 * @author Khoa Vu
 * @since March 17 2024
 */

package orderedlist;

import java.util.Arrays;
import java.util.NoSuchElementException;

public class aOrderedList {
	// SIZEINCREMENTS: Size of increments for increasing ordered list
	// oList: The ordered list containing car data
	// listSize: Current size of list
	// numObjects: Current number of elements in ordered list
	// curr: index of current element
	final int SIZEINCREMENTS = 20;
	private Comparable<Car>[] oList;
	private int listSize;
	private int numObjects;
	private int curr;
	
	// Constructor
	// Initializes values
	public aOrderedList() {
		numObjects = 0;
		listSize = SIZEINCREMENTS;
		oList = new Comparable[listSize];
		curr = -1;
	}
	
	/**
	 * Method to add new car to list
	 * @param newObject - car to be added to list
	 * 
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public void add (Comparable<Car> newObject) {
		if (numObjects >= listSize) {
			oList = Arrays.copyOf(oList, 2 * listSize);
			listSize *= 2;
		}
		
		int index = 0;
		while (index < numObjects && oList[index].compareTo((Car)newObject) < 0) {
			index++;
		}
		
		for (int i = numObjects; i > index; i--) {
			oList[i] = oList[i - 1];
		}
		
		oList[index] = newObject;
		numObjects++;
	}
	
	/**
	 * Method to get size of list
	 * @return number of objects in list
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public int size() {
		return numObjects;
	}
	
	/**
	 * Method to get element at specific position in list
	 * @param index - specific positon of list
	 * @return element at specified position
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public Comparable<Car> get(int index) {
		if (index < 0 || index >= numObjects) {
			throw new IndexOutOfBoundsException("Index out of bounds: " + index);
		}
		
		return (Car) oList[index];
	}
	
	/**
	 * Method to reset iterator parameters
	 *   
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public void reset() {
		curr = -1;
	}
	
	/**
	 * Method to return next element in iteration and increments the iterator parameters
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public Comparable<Car> next() {
		if (!hasNext()) {
			throw new NoSuchElementException("No next element in the iteration");
		}
		
		curr++;
		return (Car) oList[curr];
	}
	
	/**
	 * Method to return whether iteration has more elements to iterate through
	 * @return boolean whether next index is less than size of list
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public boolean hasNext() {
		return curr + 1 < numObjects;
	}
	
	/**
	 * Method to remove last element returned by next() method
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public void remove() {
		if (curr < 0 || curr >= numObjects) {
			throw new NoSuchElementException("No element to remove");
		}
			
		for (int i = curr; i < numObjects - 1; i++) {
			oList[i] = oList[i + 1];
		}
		
		oList[numObjects - 1] = null;
		numObjects--;
		curr--;
	}
	
	/**
	 * Method to determine if list is empty
	 * @return boolean whether number of objects in list is 0
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public boolean isEmpty() {
		return numObjects == 0;
	}
	
	/**
	 * Method to remove specific element in list
	 * @param index - specific position in list
	 * 
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public void remove(int index) {
		if (index < 0 || index >= numObjects) {
			throw new IndexOutOfBoundsException("Index out of bounds: " + index);
		}
		
		for (int i = index; i < numObjects; i++) {
			oList[i] = oList[i + 1];
		}
		
		oList[numObjects - 1] = null;
		numObjects--;
	}
	
	/**
	 * Method to delete make and year specified from list
	 * @param make - make of car
	 * @param year - year of car
	 * 
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public void delete(String make, int year) {
		for (int i = 0; i < numObjects; i++) {
	        if (oList[i] instanceof Car) {
	            Car car = (Car) oList[i];
	            if (car.getMake().equals(make) && car.getYear() == year) {
	                // Shift elements to the left to remove the car
	                for (int j = i; j < numObjects - 1; j++) {
	                    oList[j] = oList[j + 1];
	                }
	                oList[numObjects - 1] = null;
	                numObjects--;
	                return;
	            }
	        }
		}
	}
	/**
	 * Method to format ordered list in string format
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("[");
		for (int i = 0; i < numObjects; i++) {
			sb.append(oList[i].toString());
			if (i < numObjects - 1) {
				sb.append(", ");
			}
		}
		
		sb.append("]");
		return sb.toString();
		
	}
}
