/**
 * <Main driver>
 * 
 * CSC 1351 Programming Project No 1
 * Section 002
 * 
 * @author Khoa Vu
 * @since March 17 2024
 */

package orderedlist;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.io.PrintWriter;

public class Prog01_aOrderedList {
	public static void main(String[] args) throws FileNotFoundException {
		aOrderedList orderedList = new aOrderedList();
		Scanner scanner = GetInputFile("Enter input filename: ");
		
		while(scanner.hasNextLine()) {
			String line = scanner.nextLine();
			String[] parts = line.split(",");
			if (parts.length >= 4) {
				String operation = parts[0];
				
				if (operation.equalsIgnoreCase("A")) {
					String make = parts[1];
					int year = Integer.parseInt(parts[2]);
					int price = Integer.parseInt(parts[3]);
					Car newCar = new Car(make, year, price);
					orderedList.add(newCar);
					
				} else if (operation.equalsIgnoreCase("D")) {
						String deleteMake = parts[1];
						int deleteYear = Integer.parseInt(parts[2]);
						orderedList.delete(deleteMake, deleteYear);
				}
			}
		}
		
		scanner.close();
		
		PrintWriter writer = getOutputFile("Enter output filename: ");
		printFormattedList(orderedList, writer);
		System.out.println("Data written to output file successfully.");
		writer.close();
	}
	
	/**
	 * Method to get user input for input file
	 * @param UserPrompt - user input
	 * @return - N/A
	 * @throws FileNotFoundException
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
		Scanner userInput = new Scanner(System.in); 
		String fileName;
		File file;
		
		while (true) {
			System.out.print(UserPrompt);
			fileName = userInput.nextLine();
			file = new File(fileName);
			
			if (file.exists()) {
				try {
					return new Scanner(file);
				} catch (FileNotFoundException e) {
					System.out.println("Error opening file: " + e.getMessage());
				}	
			} else {
				System.out.println("File specified <" + fileName + "> does not exist.");
				System.out.print("Would you like to continue? <Y/N> ");
				String choice = userInput.nextLine();
				
				if (!choice.equalsIgnoreCase("Y")) {
					userInput.close();
					throw new FileNotFoundException("User canceled program execution.");
				}
			}
		}
	}
	
	/**
	 * Method to get user input for output file
	 * @param UserPrompt - user input
	 * @return - output file
	 * @throws FileNotFoundException
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public static PrintWriter getOutputFile(String UserPrompt) throws FileNotFoundException {
		Scanner userInput = new Scanner(System.in);
		String fileName;
		PrintWriter writer = null;
		
		while (true) {
			System.out.print(UserPrompt);
			fileName = userInput.nextLine();
			File file = new File(fileName);
			
			try {
				writer = new PrintWriter(file);
				break;
			} catch (FileNotFoundException e) {
				System.out.println("Error opening file: " + e.getMessage());
				System.out.print("Would you like to continue? <Y/N> ");
				String choice = userInput.nextLine();
				
				if (!choice.equalsIgnoreCase("Y")) {
					userInput.close();
					throw new FileNotFoundException("User canceled program execution.");
				}
			}
		}
		
		userInput.close();
		return writer;
	}
	
	/**
	 * Method to print ordered list in specific format into output file
	 * @param list - ordered list
	 * @param writer - output file
	 * 
	 *  
	 * CSC 1351 Programming Project No 1
	 * Section 002
	 * 
	 * @author Khoa Vu
	 * @since March 17 2024
	 */
	public static void printFormattedList(aOrderedList list, PrintWriter writer) {
		writer.println("Number of cars: " + list.size());
		writer.println();
		for (int i = 0; i < list.size(); i++) {
			Car car = (Car) list.get(i);
			writer.println("Make: " + car.getMake());
			writer.println("Year: " + car.getYear());
			writer.printf("Price: $%,d \n", car.getPrice());
			writer.println();
		}
	}
}
